/* msmouse.c */
int qemu_chr_open_msmouse(QemuOpts *opts, CharDriverState **_chr);
