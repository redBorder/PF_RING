/* empty_slot.c */
void empty_slot_init(target_phys_addr_t addr, uint64_t slot_size);
